Put here the licence file (.lic) received from the vendor, then run:
  docker compose exec cortexskills cortexskills-admin licence-install --file /licence/<file>.lic
