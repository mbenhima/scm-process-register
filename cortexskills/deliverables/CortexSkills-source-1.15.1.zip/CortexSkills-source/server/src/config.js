import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
export const ROOT = path.resolve(here, '..');
const EDITION = (() => { try { return JSON.parse(fs.readFileSync(path.join(ROOT, 'edition.json'), 'utf8')); } catch { return null; } })();

// Optional .env file (KEY=VALUE lines) next to package.json, or the file named by CORTEXSKILLS_ENV (the delivered
// runtimes keep it at the root of the package). Real environment variables win.
const envFile = process.env.CORTEXSKILLS_ENV || path.join(ROOT, '.env');
if (fs.existsSync(envFile)) {
  for (const line of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^"|"$/g, '');
  }
}

const dataDir = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(ROOT, 'data');

export const config = {
  port: Number(process.env.PORT || 4000),
  // Network interface to listen on (HOST=127.0.0.1 behind a reverse proxy); every interface when empty.
  host: process.env.HOST || undefined,
  dataDir,
  dbFile: path.join(dataDir, 'cortexskills.db'),
  backupDir: path.join(dataDir, 'backups'),
  attachmentDir: path.join(dataDir, 'attachments'),
  licenceFile: process.env.LICENSE_PATH || path.join(dataDir, 'license.lic'),
  // OnPrem: the vendor public key that verifies licence files. A fixed place inside the application (read-only in the
  // container image): it cannot be pointed elsewhere by a setting.
  vendorPublicKeyFile: () => { const f = path.join(ROOT, 'tools', 'keys', 'vendor-public.pem'); return fs.existsSync(f) ? f : null; },
  jwtSecret: process.env.JWT_SECRET || 'cortexskills-local-development-secret-change-me',
  jwtTtl: process.env.JWT_TTL || '12h',
  hmacSecret: process.env.LICENSE_HMAC_SECRET || 'cortexskills-licence-hmac-local-secret',
  // A delivered runtime (edition.json, written by tools/build-runtime.mjs) always runs on-premises under a signed
  // licence, and the customer edition never shows commercial information, whatever .env says.
  deploymentMode: EDITION ? 'onprem' : (process.env.DEPLOYMENT_MODE || 'saas').toLowerCase(),
  // Customer edition: COMMERCIAL_INFO=hidden removes prices, quotes and the pricing screen (on-premises customers).
  commercialInfo: EDITION?.edition === 'customer' ? false : String(process.env.COMMERCIAL_INFO || 'shown').toLowerCase() !== 'hidden',
  edition: EDITION?.edition || null,
  backupRetentionDays: Number(process.env.BACKUP_RETENTION_DAYS || 14),
  corsOrigin: process.env.CORS_ORIGIN || '*',
  // Base URL of the web client, used in the response links sent by email and WhatsApp (falls back to the request origin).
  publicUrl: (process.env.PUBLIC_URL || '').replace(/\/$/, ''),
  // Key protecting stored channel credentials and response links (AES-256-GCM). Set it in production.
  secretKey: process.env.CHANNEL_SECRET_KEY || process.env.JWT_SECRET || 'cortexskills-local-development-secret-change-me',
  // Platform-wide channel defaults, used by an Organization that has not configured its own provider.
  smtp: { host: process.env.SMTP_HOST || '', port: Number(process.env.SMTP_PORT || 587), secure: process.env.SMTP_SECURE === 'true', user: process.env.SMTP_USER || '', pass: process.env.SMTP_PASS || '', from: process.env.SMTP_FROM || '' },
  whatsapp: { apiBase: (process.env.WHATSAPP_API_BASE || 'https://graph.facebook.com/v21.0').replace(/\/$/, ''), token: process.env.WHATSAPP_TOKEN || '', phoneNumberId: process.env.WHATSAPP_PHONE_NUMBER_ID || '',
    verifyToken: process.env.WHATSAPP_VERIFY_TOKEN || '', appSecret: process.env.WHATSAPP_APP_SECRET || '', template: process.env.WHATSAPP_TEMPLATE || '', templateLang: process.env.WHATSAPP_TEMPLATE_LANG || '' },
  // Most rows a user may paste into a Multi-Entry at once (SRS 1.8 FR-DA-MRE-22).
  pasteMaxRows: Math.max(1, Number(process.env.PASTE_MAX_ROWS || 1000)),
  // Bulk import of a file (FR-DA-MRE, import workflow): maximum size and rows; rows are sent in batches of IMPORT_BATCH.
  importMaxBytes: Math.max(1024, Number(process.env.IMPORT_MAX_BYTES || 5 * 1024 * 1024)),
  importMaxRows: Math.max(1, Number(process.env.IMPORT_MAX_ROWS || 10000)),
  importBatch: Math.min(500, Math.max(50, Number(process.env.IMPORT_BATCH || 250))),
  minNode: '22.13.0',
  cacheTtlMs: 30000,
};

for (const d of [config.dataDir, config.backupDir, config.attachmentDir]) fs.mkdirSync(d, { recursive: true });
