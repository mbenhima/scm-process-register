#!/usr/bin/env node
import o from"node:crypto";const E=()=>o.randomBytes(48).toString("base64url");console.log(`JWT_SECRET=${E()}
CHANNEL_SECRET_KEY=${E()}
LICENSE_HMAC_SECRET=${E()}`);
