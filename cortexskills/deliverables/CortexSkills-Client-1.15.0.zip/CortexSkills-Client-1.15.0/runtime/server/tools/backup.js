#!/usr/bin/env node
const{migrate:t,isSeeded:a}=await import("../src/db.js");t(),a()||(console.error('The database is empty. Run "npm run seed" first.'),process.exit(1));const{backupNow:o}=await import("../src/services/ops.js"),e=o("on-demand");console.log(`Backup written: data/backups/${e.file} (${Math.round(e.size/1024)} KB)`);
