#!/usr/bin/env node
import e from"node:fs";import r from"node:path";import{config as o}from"../src/config.js";const s=process.argv[2],l=e.existsSync(o.backupDir)?e.readdirSync(o.backupDir).filter(n=>n.endsWith(".db")).sort():[];s||(console.log(`
  Usage: restore <backup file>
  Backups in ${o.backupDir}:
${l.map(n=>"   "+n).join(`
`)||"   (none)"}
`),process.exit(1));const t=e.existsSync(s)?r.resolve(s):r.join(o.backupDir,r.basename(s));e.existsSync(t)||(console.error(`
  No backup named ${s}. Run restore without a name to list them.
`),process.exit(1));const i=Buffer.alloc(16),a=e.openSync(t,"r");e.readSync(a,i,0,16,0),e.closeSync(a),i.toString("latin1")!=="SQLite format 3\0"&&(console.error(`
  This file is not a CortexSkills backup (not an SQLite database).
`),process.exit(1));const c=new Date().toISOString().replace(/[:.]/g,"-");e.existsSync(o.dbFile)&&e.copyFileSync(o.dbFile,r.join(o.backupDir,`before-restore-${c}.db`));for(const n of["-wal","-shm"])e.rmSync(o.dbFile+n,{force:!0});e.copyFileSync(t,o.dbFile),console.log(`
  Restored ${r.basename(t)} into ${o.dbFile}.
  The previous database is kept as before-restore-${c}.db. Start the server again.
`);
