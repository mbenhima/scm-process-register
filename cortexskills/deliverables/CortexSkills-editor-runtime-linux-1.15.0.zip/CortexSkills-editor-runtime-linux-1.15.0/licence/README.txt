Licence files (.lic) signed on your laptop go here: ./licence.sh install licence/<file>.lic
