# DynamicMS — Integrated Management System

DynamicMS runs the whole lifecycle of a management system (QMS or QHSE): 12 end-to-end phases, 162 macro processes and 1,572 workflow steps. Each step has its own input form. The platform also handles gates and checklists, governance (rules, COSO controls, risks, RACSI, KPIs), records (nonconformities, actions, audits, documents, registers), alerts, AI use cases with a human checkpoint, reports, portfolio and benchmarking. It works in English, French and Arabic (right to left).

## Quick start

Requirement: Node.js 22.13 or later. The built-in `node:sqlite` module is the database, so no database server is needed.

```bash
cd server
npm install
npm run seed      # creates data/dynamicms.db: 60 organizations, 120 full-run projects, 84,603 steps
npm run dev       # API on http://localhost:4000

cd ../web
npm install
npm run dev       # open http://localhost:5173
```

Sign in with `quality@horizon-universal.example`, `ims@atlas-sme.example` or `quality@nova-aec.example`. The password for every organization account is `Demo@2026`. The platform administrator is `admin@dynamicms.example` with password `Admin@2026`.

## Production deployment (Docker)

`Dockerfile` builds one production image. Two ready-to-use folders run it:

- `deploy/editor/`: editor side (SaaS). Starts empty, with the platform administrator from `.env` and an optional setup file that creates groups, organizations, users and projects.
- `deploy/customer/`: customer side (on-premises), with the seeded data and licence enforcement.

In production mode (`APP_MODE=production`) the sign-in page lists no account, the built-in demonstration administrator does not exist, and every account changes its initial password at first sign-in. See the README of each folder.

## Upgrade

Replace the files, keep `server/data/`, then restart the server: it migrates the data in place at its first start (no reseed). See `RELEASE_NOTES.md`.

## Demonstration data

| Tenancy | Organizations | Projects |
|---|---|---|
| Horizon Industrial Group | 29 large companies (one per vertical) + Horizon Universal Holdings | QMS and QHSE full runs each |
| Nova SME Alliance | 29 SMEs (one per vertical) | QMS and QHSE full runs each |
| Independent | Atlas Universal SME | QMS and QHSE full runs |

Each organization has 19 accounts named `role@domain`: ims, quality, hse, risk, compliance, audit, hr, documents, it, operations, performance, esg, transformation, process, admin, ceo, employee, aigov and auditor. All names and texts are fictional and exist in the three languages.

## Structure

- `server/`: Express REST API, SQLite schema and migrations, catalog builder, full-run seed generator, reports (PDF, Excel, Word, PowerPoint, CSV; PowerPoint in `src/services/pptx.js`), IMS document templates (37, in `src/content/templates.js`) and the generator that fills them from the project data (`src/services/docdata.js`), AI engine (rules plus retrieval, with optional language models: Claude, OpenAI, Azure OpenAI, Gemini, Mistral or a custom OpenAI-compatible endpoint, set under Administration › AI models), global search, process design editor with versions and restore (`src/routes/design.js`), OBS roles linked to functions, AI prompt specifications with versioned fields, BPMN and process-map diagrams for documents (`src/services/diagram.js`, rendered with @resvg/resvg-wasm), backups, licence tools and tests (`npm test`).
- `server/src/routes/ptemplates.js` and `src/services/blueprint.js`: project templates as editable blueprints (end-to-end processes, macro processes, steps, rules, controls, risks, alerts, KPIs, reporting) applied at project creation.
- `web/`: React + Vite client. It uses the design tokens of the AI Value graphical chart 1.2 in `src/styles/tokens.css`, a navigation shell that can be docked on any edge with resizable panels (`src/lib/layout.jsx`), paginated tables, inline editable tables (`src/components/InlineGrid.jsx`), document formatting and picture editors (`src/components/DocEditors.jsx`) and bundled fonts.
- `tools/`: extraction of the source documents, translation tables, screenshot and document generators.
- `docs/sources/`: the five source documents.
- `deliverables/`: installation guide, user guide "One full real run" (EN, FR: all 12 end-to-end processes of the universal scenario, each step followed by what to type, PDCA, process review from data sources to reports), earlier user guides (EN, FR), IMS document templates (EN, FR), sample generated IMS documents of the universal scenario, one folder per end-to-end process plus reports (EN, FR), feedback responses, application standard SRS, presentations (EN, FR), coverage checklist, the application zip and the source code zip.
- Visual identity: AI Value graphical chart 1.2 (navy, azure, green and teal palette; Montserrat, Open Sans and JetBrains Mono), with the DynamicMS logo in the app, "A solution by" AI Value and FlexiGlob on the sign-in page and the AI Value logo on every deliverable.

The development server pre-bundles its dependencies at start-up; if a first load is interrupted, the page reloads itself once. For daily use, build the client and open the application on port 4000.

The seed generates 6,392 documents (Word, PDF, Excel or PowerPoint) from the templates, filled with each project's data and ready to download from Records › Documents.

## End-to-end processes

E2E-01 Context To Strategy, E2E-02 Leadership To Commitment, E2E-03 Risk To Resilience, E2E-04 Compliance To Achievement, E2E-05 Resources To Readiness, E2E-06 Infrastructure To Security, E2E-07 Data To Intelligence, E2E-08 Requirements To Delivery, E2E-09 Nonconformity To Knowledge, E2E-10 Monitoring To Evaluation, E2E-11 Intelligence To Assurance, E2E-12 Improvement To Innovation. Databases seeded with the former names are updated at start-up (`server/src/catalog/renames.js`).

## Production

```bash
cd web && npm run build
cd ../server && JWT_SECRET=<long random value> NODE_ENV=production npm start   # serves the API and the web client on port 4000
```

See `deliverables/DynamicMS_Installation_Guide.pdf` for configuration, backups, on-premises licensing and troubleshooting.

## Editions and runtime images (customer, editor)

The same code builds three editions, chosen at build time (`__EDITION__`):

| Edition | Use | Commercial data | Licences |
|---|---|---|---|
| `dev` | Development from the source (`npm run dev`, `npm start`) | Shown | Issued and verified |
| `editor` | The editor's production platform (SaaS, private cloud, or localhost on Windows) | Shown | Issued, changed, revoked (Administration › Licences) |
| `customer` | The customer's on-premises platform | Removed (prices, bundles, discounts, quotes) | Verified with the embedded public key only |

`runtime/` builds the production images, without application source code:

```bash
cd runtime && npm ci
./build-image.sh customer   # or: editor
```

- Server: bundled, tree-shaken and minified (esbuild), then compiled to V8 bytecode in the image.
- Web client: minified JavaScript and CSS, chunks loaded on demand, Brotli and gzip copies served as they are; hashed assets cached for a year.
- Output: `runtime/dist/Docker_Runtime_<Edition>_Linux_DynamicMS_2026.10_Image.tar.gz` and its SHA-256.
- Installation packages: `runtime/deploy/customer-linux`, `editor-linux`, `editor-windows`. French guides in `deliverables/Guide_Installation_Docker_Runtime_*`.
- The licence signing key (private) is never in the repository; `runtime/keys/` holds only the public key embedded in the customer edition.
