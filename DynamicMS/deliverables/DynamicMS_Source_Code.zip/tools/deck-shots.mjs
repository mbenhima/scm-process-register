// Captures the screenshots used by the presentations and user guides.
// Requires the server on :4000 serving the built web client.
// Usage: node tools/deck-shots.mjs <lang> <outDir>
import { createRequire } from 'node:module';
import { execSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const require = createRequire(path.join(execSync('npm root -g').toString().trim(), 'noop.js'));
const { chromium } = require('playwright');
const [lang = 'en', outDir = 'deliverables/build/deck-en'] = process.argv.slice(2);
const BASE = process.env.BASE || 'http://localhost:4000';
fs.mkdirSync(outDir, { recursive: true });

async function tokenFor(email, password = 'Demo@2026') {
  const r = await fetch(`${BASE}/api/auth/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }) });
  return (await r.json()).token;
}
const admin = await tokenFor('admin@dynamicms.example', 'Admin@2026');
const H = (t) => ({ Authorization: `Bearer ${t}`, 'Content-Type': 'application/json' });
const tree = await (await fetch(`${BASE}/api/tenancy/tree`, { headers: H(admin) })).json();
const orgs = [...tree.groups.flatMap(g => g.orgs), ...tree.independent];
const projByCode = {}; for (const o of orgs) for (const p of o.projects) projByCode[p.code] = p.id;

const browser = await chromium.launch();
const errors = [];
async function session(email, password) {
  const tk = await tokenFor(email, password);
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 860 }, deviceScaleFactor: 1.5, locale: lang === "fr" ? "fr-FR" : "en-GB" });
  await ctx.addInitScript(([t, l]) => { sessionStorage.setItem('dms.token', t); localStorage.setItem('dms.lang', l); localStorage.setItem('dms.lang.chosen', '1'); }, [tk, lang]);
  const page = await ctx.newPage();
  page.on('pageerror', e => errors.push(e.message));
  return { tk, page, ctx };
}
async function shoot(s, projectCode, route, name, opts = {}) {
  await fetch(`${BASE}/api/auth/prefs`, { method: 'PUT', headers: H(s.tk), body: JSON.stringify({ projectId: projByCode[projectCode], lang }) });
  await s.page.goto(`${BASE}${route}`, { waitUntil: 'networkidle' });
  await s.page.waitForTimeout(600);
  if (opts.tab) { await s.page.getByRole('tab', { name: opts.tab }).first().click(); await s.page.waitForLoadState('networkidle'); await s.page.waitForTimeout(opts.wait || 900); }
  if (opts.click) { await s.page.getByText(opts.click, { exact: false }).first().click(); await s.page.waitForTimeout(700); }
  if (opts.scroll) { await s.page.evaluate((y) => window.scrollTo(0, y), opts.scroll); await s.page.waitForTimeout(300); }
  await s.page.screenshot({ path: path.join(outDir, `${name}.png`) });
  process.stdout.write('.');
}

// 1) One lifecycle screenshot per sector (large company QMS run) + SME dashboard
const verticalOrgs = orgs.filter(o => o.size === 'Large');
const adminS = await session('admin@dynamicms.example', 'Admin@2026');
for (const o of verticalOrgs) {
  const code = o.projects.find(p => p.ms_type === 'QMS')?.code;
  await shoot(adminS, code, '/lifecycle', `sector-${o.sector}`, { scroll: 250 });
}
for (const o of orgs.filter(x => x.size === 'SME')) {
  const code = o.projects.find(p => p.ms_type === 'QHSE')?.code;
  await shoot(adminS, code, '/', `sme-${o.code}`);
}

// 2) Feature screenshots on the scenario projects
const t = {
  en: { bpmn: 'BPMN diagram', sipoc: 'SIPOC', group: 'Across my group' },
  fr: { bpmn: 'Diagramme BPMN', sipoc: 'SIPOC', group: 'Dans mon groupe' },
}[lang] || {};
const q = await session('quality@horizon-universal.example');
const stepsTodo = await (await fetch(`${BASE}/api/projects/${projByCode['HZ-UNI-QMS']}/steps?status=Todo&limit=1`, { headers: H(q.tk) })).json();
const stepsDone = await (await fetch(`${BASE}/api/projects/${projByCode['HZ-UNI-QMS']}/steps?status=Done&limit=60`, { headers: H(q.tk) })).json();
const doneAssess = stepsDone.items.find(x => x.form_kind === 'assess') || stepsDone.items[0];
await shoot(q, 'HZ-UNI-QMS', '/', 'f-home');
await shoot(q, 'HZ-UNI-QMS', '/lifecycle', 'f-lifecycle');
await shoot(q, 'HZ-UNI-QMS', '/lifecycle/E2E-11', 'f-gate', { scroll: 700 });
await shoot(q, 'HZ-UNI-QMS', `/steps/${stepsTodo.items[0].id}`, 'f-step');
await shoot(q, 'HZ-UNI-QMS', `/steps/${doneAssess.id}`, 'f-step-done');
await shoot(q, 'HZ-UNI-QMS', '/mp/MP-018', 'f-mp');
await shoot(q, 'HZ-UNI-QMS', '/mp/MP-018', 'f-sipoc', { tab: t.sipoc });
await shoot(q, 'HZ-UNI-QMS', '/mp/MP-002', 'f-bpmn', { tab: t.bpmn, wait: 2500 });
await shoot(q, 'HZ-UNI-QHSE', '/risks', 'f-risks');
await shoot(q, 'HZ-UNI-QMS', '/kpis', 'f-kpis');
await shoot(q, 'HZ-UNI-QMS', '/racsi', 'f-racsi');
await shoot(q, 'HZ-UNI-QMS', '/ncs', 'f-ncs');
await shoot(q, 'HZ-UNI-QMS', '/documents', 'f-documents');
await shoot(q, 'HZ-UNI-QMS', '/planning', 'f-planning');
await shoot(q, 'HZ-UNI-QMS', '/reports', 'f-reports');
await shoot(q, 'HZ-UNI-QMS', '/alerts', 'f-alerts');
await shoot(q, 'HZ-UNI-QMS', '/ai', 'f-ai');
await shoot(q, 'HZ-UNI-QMS', '/process', 'f-process');
const ceo = await session('ceo@horizon-aut.example');
await shoot(ceo, 'HZ-AUT-QMS', '/portfolio', 'f-portfolio');
await shoot(ceo, 'HZ-AUT-QMS', '/benchmark', 'f-benchmark', { tab: t.group, wait: 2500 });
const sme = await session('ims@atlas-sme.example');
await shoot(sme, 'AT-UNI-QMS', '/projects/new', 'f-newproject', { click: lang === 'fr' ? 'Avec l' : 'With AI' });
// Features added after the feedback on User Guide 2
const L2 = { en: { tpl: 'Templates', mand: 'Required by the standards', llm: 'AI models' }, fr: { tpl: 'Modèles', mand: 'Exigés par les normes', llm: "Modèles d'IA" } }[lang] || {};
const smeSteps = await (await fetch(`${BASE}/api/projects/${projByCode['AT-UNI-QMS']}/steps?mp=MP-001&limit=20`, { headers: H(sme.tk) })).json();
const smeMatrix = await (await fetch(`${BASE}/api/projects/${projByCode['AT-UNI-QMS']}/steps?mp=MP-002&limit=20`, { headers: H(sme.tk) })).json();
await shoot(sme, 'AT-UNI-QMS', `/steps/${smeSteps.items.find(x => x.step_id === 'MP-001.2').id}`, 'f-rows', { scroll: 380 });
await shoot(sme, 'AT-UNI-QMS', `/steps/${smeMatrix.items.find(x => x.step_id === 'MP-002.12').id}`, 'f-matrix', { scroll: 380 });
await shoot(sme, 'AT-UNI-QMS', '/documents', 'f-mandatory', { tab: L2.mand });
await shoot(sme, 'AT-UNI-QMS', '/documents', 'f-templates', { tab: L2.tpl });
await shoot(sme, 'AT-UNI-QMS', '/mp/MP-004', 'f-racsi-mp', { tab: 'RACSI' });
const tadm = await session('admin@atlas-sme.example');
await shoot(tadm, 'AT-UNI-QMS', '/admin', 'f-llm', { tab: L2.llm });
// SRS 1.5 features: global search, process design editor, roles and functions, prompt
// specification, audit frequency, register entry details
const L3 = { en: { search: 'interested parties', prompt: 'Prompt specification' }, fr: { search: 'parties intéressées', prompt: 'Spécification du prompt' } }[lang] || {};
await fetch(`${BASE}/api/auth/prefs`, { method: 'PUT', headers: H(tadm.tk), body: JSON.stringify({ projectId: projByCode['AT-UNI-QMS'], lang }) });
await tadm.page.goto(`${BASE}/`, { waitUntil: 'networkidle' }); await tadm.page.keyboard.press('Control+k'); await tadm.page.keyboard.type(L3.search); await tadm.page.waitForTimeout(1300);
await tadm.page.screenshot({ path: path.join(outDir, 'f-search.png') }); await tadm.page.keyboard.press('Escape'); process.stdout.write('.');
await shoot(tadm, 'AT-UNI-QMS', '/design?type=step', 'f-design');
await tadm.page.locator('table tbody tr').nth(1).click(); await tadm.page.waitForTimeout(900); await tadm.page.screenshot({ path: path.join(outDir, 'f-design-edit.png') }); process.stdout.write('.');
await shoot(tadm, 'AT-UNI-QMS', '/organization?tab=roles', 'f-roles');
await tadm.page.goto(`${BASE}/ai`, { waitUntil: 'networkidle' }); await tadm.page.waitForTimeout(600); await tadm.page.locator('table tbody tr').first().click(); await tadm.page.waitForTimeout(500);
await tadm.page.getByRole('button', { name: L3.prompt }).click(); await tadm.page.waitForTimeout(1200); await tadm.page.screenshot({ path: path.join(outDir, 'f-prompt.png') }); process.stdout.write('.');
await shoot(sme, 'AT-UNI-QMS', '/audits', 'f-audits');
const smeAudits = await (await fetch(`${BASE}/api/projects/${projByCode['AT-UNI-QMS']}/audits`, { headers: H(sme.tk) })).json();
const doneAudit = smeAudits.find(a => a.status === 'Completed' && a.findings > 1) || smeAudits[0];
await shoot(sme, 'AT-UNI-QMS', `/audits/${doneAudit.id}`, 'f-audit-detail');
await shoot(sme, 'AT-UNI-QMS', '/registers?reg=calibration', 'f-register');
await sme.page.locator('table tbody tr').first().click(); await sme.page.waitForTimeout(600); await sme.page.screenshot({ path: path.join(outDir, 'f-register-entry.png') }); process.stdout.write('.');
// Round 3: needs mapped to interested parties; a row opened in the large editor.
await shoot(sme, 'AT-UNI-QMS', `/steps/${smeSteps.items.find(x => x.step_id === 'MP-001.5').id}`, 'f-needs', { scroll: 420 });
await shoot(sme, 'AT-UNI-QMS', `/steps/${smeSteps.items.find(x => x.step_id === 'MP-001.2').id}`, 'f-row-editor', { scroll: 380 });
await sme.page.locator('.row-actions button').first().click(); await sme.page.waitForTimeout(700); await sme.page.screenshot({ path: path.join(outDir, 'f-row-editor.png') }); process.stdout.write('.');
// Round 4: project templates, document template formatting and pictures, pagination,
// BPMN palette, sign-in page with the partner logos.
const L4 = { en: { proc: 'Processes and steps', risks: 'Risks and opportunities', tpl: 'Templates', fmt: 'Formatting', struct: 'Structure', bpmn: 'BPMN diagram' }, fr: { proc: 'Processus et étapes', risks: 'Risques et opportunités', tpl: 'Modèles', fmt: 'Mise en forme', struct: 'Structure', bpmn: 'Diagramme BPMN' } }[lang] || {};
const ptList = await (await fetch(`${BASE}/api/project-templates`, { headers: H(sme.tk) })).json();
const own = ptList.find(x => !x.library) || ptList[0];
await shoot(sme, 'AT-UNI-QMS', '/project-templates', 'f-ptemplates');
await shoot(sme, 'AT-UNI-QMS', `/project-templates/${own.id}`, 'f-ptemplate');
await shoot(sme, 'AT-UNI-QMS', `/project-templates/${own.id}?tab=processes`, 'f-ptemplate-proc');
await sme.page.locator('.tpl-phase-btn').first().click(); await sme.page.waitForTimeout(300);
await sme.page.locator('table.data tbody tr td button[aria-expanded]').first().click(); await sme.page.waitForTimeout(500);
await sme.page.locator('.tpl-steps').first().scrollIntoViewIfNeeded(); await sme.page.evaluate(() => window.scrollBy(0, 160)); await sme.page.waitForTimeout(300);
await sme.page.screenshot({ path: path.join(outDir, 'f-ptemplate-steps.png') }); process.stdout.write('.');
await shoot(sme, 'AT-UNI-QMS', `/project-templates/${own.id}?tab=risks`, 'f-ptemplate-risks');
await shoot(sme, 'AT-UNI-QMS', '/documents', 'f-doctpl', { tab: L4.tpl });
await sme.page.getByText('TPL-SCOPE', { exact: true }).first().click(); await sme.page.waitForTimeout(1200);
await sme.page.locator('.pic-editor').first().scrollIntoViewIfNeeded(); await sme.page.waitForTimeout(1000);
await sme.page.screenshot({ path: path.join(outDir, 'f-doctpl-picture.png') }); process.stdout.write('.');
await sme.page.getByRole('tab', { name: L4.fmt }).click(); await sme.page.waitForTimeout(1000);
await sme.page.screenshot({ path: path.join(outDir, 'f-doctpl-format.png') }); process.stdout.write('.');
await shoot(sme, 'AT-UNI-QMS', '/actions', 'f-pager');
await sme.page.locator('.pager').first().scrollIntoViewIfNeeded(); await sme.page.waitForTimeout(400); await sme.page.screenshot({ path: path.join(outDir, 'f-pager.png') }); process.stdout.write('.');
await shoot(adminS, 'HZ-AEC-QMS', '/mp/MP-017', 'f-bpmn-palette', { tab: L4.bpmn, wait: 2500 });
const anon = await browser.newContext({ viewport: { width: 1440, height: 860 }, deviceScaleFactor: 1.5, locale: lang === 'fr' ? 'fr-FR' : 'en-GB' });
await anon.addInitScript((l) => { localStorage.setItem('dms.lang', l); localStorage.setItem('dms.lang.chosen', '1'); }, lang);
const ap = await anon.newPage(); await ap.goto(`${BASE}/`, { waitUntil: 'networkidle' }); await ap.waitForTimeout(600);
await ap.screenshot({ path: path.join(outDir, 'f-login.png') }); process.stdout.write('.'); await anon.close();
const asst = await session('quality@nova-aec.example');
await asst.page.goto(`${BASE}/assistant`, { waitUntil: 'networkidle' });
process.stdout.write('\n');
if (errors.length) console.log('ERRORS', [...new Set(errors)].join('\n'));
await browser.close();
console.log('done', outDir);
