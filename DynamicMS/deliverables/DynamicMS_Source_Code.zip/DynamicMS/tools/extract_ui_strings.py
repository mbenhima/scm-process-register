"""Collects every t('...') UI string of the web client into tools/i18n/ui.en.txt
(one per line, numbered) so French and Arabic translations can be kept in
tools/i18n/ui.fr.txt and tools/i18n/ui.ar.txt with the same numbering, then
writes web/src/lib/dict.js."""
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'web', 'src')
OUT = os.path.join(ROOT, 'tools', 'i18n')
PAT = re.compile(r"""\bt\(\s*(['"])((?:\\.|(?!\1).)*)\1""")
EXTRA = re.compile(r"""label:\s*'([^']+)'|group:\s*'([^']+)'|\[\s*'(start|end|top|bottom)',\s*\w+,\s*'([^']+)'\]""")


EXTRA_STRINGS = [
    'How do I reopen a completed step?', 'How do I report a problem?', 'Can the same person own and evaluate an action?',
    'What does ISO 45001 require for hazard identification?', 'What is a BIM execution plan?', 'Which clauses cover the management review?',
    'Which steps are overdue?', 'What are my tasks?', 'Which KPIs are off target?', 'Where is the project?', 'What are the top risks?',
    'Context issues', 'Interested parties', 'Objectives', 'Compliance obligations', 'Certificates', 'Improvement ideas', 'Competence', 'Calibration', 'Management reviews', 'Incidents',
    'Impact', 'Needs and expectations', 'Influence', 'Interest', 'KPI', 'Current value', 'Deadline', 'Evaluation', 'Last evaluated', 'Certification body', 'Issued', 'Expiry', 'Number',
    'Critical', 'Last evaluation', 'ROI (%)', 'Effort', 'Submitted by', 'Holder', 'Level', 'Required level', 'Trained on', 'Serial number', 'Last calibration', 'Next calibration', 'Location',
    'Attendees', 'Lost days', 'Investigated',
    'Rule actions', 'Process risks', 'Process KPIs', 'Reports', 'Document templates', 'Policies', 'Object classes', 'Data dictionary', 'Value lists', 'Role menus', 'Modules', 'Unified functional steps',
    'Containment', 'Corrective', 'Preventive', 'Improvement', 'Go', 'Hold', 'No-Go',
    'complete', 'save', 'reopen', 'assign', 'create', 'update',
    'periodicity', 'list', 'assess', 'decision', 'document', 'communicate', 'train', 'monitor', 'plan', 'execute', 'configure', 'close', 'escalate', 'ai', 'service',
    'Text Generation', 'Summarization', 'Classification', 'Recommendation', 'Prediction',
    'Step', 'End-to-end process', 'Place in the application', 'Works', 'Authentication failure', 'Model not found', 'Rate limited', 'Unreachable',
    'The provider is disabled; enable it first.', 'Choose a provider and a model and type the key (and the HTTPS endpoint for a custom model).',
    'Seeded', 'Custom', 'Duplicate', 'Suggested', 'Draft', 'Approved',
    'Base packs', 'Industry packs', 'Capability packs', 'Add-ons', 'Compliance & Security Standards', 'Signing key ready.',
    'No signing key: place the editor private key at this path.', 'This key does not match the key of the customer installations: their licences would be refused.',
    'Revoked', 'Expired', 'Active', 'Mode', 'Version', 'No licence installed.', 'The licence file cannot be read.', 'Licence valid.', 'Licence signature is invalid.', 'Licence expired.', 'Entitlements are managed by the platform configuration.',
    'Brief', 'Detailed description', 'Goal', 'Goals', 'Trigger', 'End', 'Phase (E2E)', 'Order', 'Purpose', 'Entry criteria', 'Exit criteria', 'Approvers (one per line)', 'Items (one per line)', 'Macro process', 'Task',
]


def collect():
    found = []
    for base, _, files in os.walk(SRC):
        for f in sorted(files):
            if not f.endswith(('.jsx', '.js')) or f == 'dict.js':
                continue
            text = open(os.path.join(base, f), encoding='utf8').read()
            for m in PAT.finditer(text):
                s = m.group(2).replace("\\'", "'").replace('\\"', '"')
                if s and s not in found:
                    found.append(s)
            if f == 'Shell.jsx':
                for m in EXTRA.finditer(text):
                    for g in m.groups():
                        if g and g not in ('start', 'end', 'top', 'bottom') and g not in found:
                            found.append(g)
    for x in EXTRA_STRINGS:
        if x not in found:
            found.append(x)
    return found


def load(lang):
    out = {}
    for f in sorted(os.listdir(OUT)):
        if not re.match(rf'ui\.{lang}(\.\d+)?\.txt$', f):
            continue
        for line in open(os.path.join(OUT, f), encoding='utf8'):
            line = line.rstrip('\n')
            if '\t' in line:
                n, s = line.split('\t', 1)
                out[int(n)] = s
    return out


def main():
    os.makedirs(OUT, exist_ok=True)
    en_path = os.path.join(OUT, 'ui.en.txt')
    existing = []
    if os.path.exists(en_path):
        existing = [l.rstrip('\n').split('\t', 1)[1] for l in open(en_path, encoding='utf8') if '\t' in l]
    strings = existing + [s for s in collect() if s not in existing]
    with open(en_path, 'w', encoding='utf8') as fh:
        for i, s in enumerate(strings, 1):
            fh.write(f'{i}\t{s}\n')
    fr, ar = load('fr'), load('ar')
    d = {}
    missing = 0
    for i, s in enumerate(strings, 1):
        e = {}
        if i in fr:
            e['fr'] = fr[i]
        if i in ar:
            e['ar'] = ar[i]
        if len(e) < 2:
            missing += 1
        if e:
            d[s] = e
    with open(os.path.join(SRC, 'lib', 'dict.js'), 'w', encoding='utf8') as fh:
        fh.write('// Generated by tools/extract_ui_strings.py — UI strings in French and Arabic.\n')
        fh.write('export const DICT = ' + json.dumps(d, ensure_ascii=False, indent=0) + ';\n')
    print(f'{len(strings)} UI strings; {missing} without both translations')
    if '--missing' in sys.argv:
        for i, s in enumerate(strings, 1):
            if i not in fr or i not in ar:
                print(f'{i}\t{s}')


if __name__ == '__main__':
    main()
