// Module 5 — Change Management Charter Registry (D31).
// 8 charters, each a signed, trackable behavioral standard (not prose guidance)
// governing a specific role's expected behavior across the change lifecycle.
// R/A/C/S/I use the same 7-code RACSI taxonomy as Module 4's E2E chains
// (D17 CAT-02: ES/CM/PM/FPO/ITL/SUP/EU) — distinct from journi's platform
// ROLES enum. Governs_OBS_Level mirrors Module 1's Group/Organization/Project
// hierarchy. Charter-to-task/step mapping lives separately in charterActions.js
// (D31a) — a charter can govern actions across many macro processes at once,
// so that many-to-many relationship is deliberately not embedded here.
//
// Each charter is a named container for one or more entries — a charter can
// cover more than one specific behavioral commitment (e.g. a distinct
// category/owner/what/who/when/where/why/how), each independently added,
// edited, and removed (Module 5's Manage Charters editor). Charter-level
// fields (status, version, RACSI, governance level) describe the charter as
// a whole; entry-level fields describe one specific commitment within it.
const charters = [
  {
    id: 'CHTR-01',
    name: 'Sponsorship / Leadership Charter',
    pdcaCycle: 'Full Cycle (Plan-Do-Check-Act)',
    racsi: { R: 'CM', A: 'ES', C: 'PM, FPO', S: '-', I: 'SUP, EU' },
    primaryLinkedMacroId: 'MP-02',
    governsObsLevel: 'Project',
    status: 'Active',
    version: 'v1.0',
    effectiveDate: '2026-06-09',
    reviewFrequency: 'Per Phase Gate',
    entries: [
      {
        id: 'CHTR-01-E1',
        category: 'Sponsorship & Governance',
        owner: 'Executive Sponsor',
        what: 'Defines the specific, observable sponsorship behaviors expected of the Executive Sponsor and Steering Committee across the initiative lifecycle.',
        who: 'Executive Sponsor (primary subject); Change Manager (facilitates); Steering Committee (co-signs)',
        when: 'Signed at project kickoff; reviewed at every Phase Gate',
        where: 'Steering Committee governance forum (Module 13)',
        why: 'Prosci research shows active, visible sponsorship is the single largest predictor of change success; an unwritten expectation is an unenforceable one.',
        how: 'A structured charter document naming specific actions (town halls attended, escalations resolved, communications sent) rather than a generic "be supportive" commitment; tracked via the Sponsor-visibility tracker (Module 13).',
        description:
          'Operationalizes the Prosci Sponsor Model and Kotter Step 2 (Build a Guiding Coalition) as a signed, trackable commitment rather than prose guidance.',
      },
    ],
  },
  {
    id: 'CHTR-02',
    name: 'Participative Management Charter',
    pdcaCycle: 'Full Cycle (Plan-Do-Check-Act)',
    racsi: { R: 'SUP', A: 'CM', C: 'FPO, PM', S: '-', I: 'ES, EU' },
    primaryLinkedMacroId: 'MP-04',
    governsObsLevel: 'Project',
    status: 'Active',
    version: 'v1.0',
    effectiveDate: '2026-06-09',
    reviewFrequency: 'Quarterly',
    entries: [
      {
        id: 'CHTR-02-E1',
        category: 'Frontline Engagement',
        owner: 'Frontline Supervisor',
        what: 'Defines how Frontline Supervisors and People Managers involve their teams in decisions that affect them, rather than announcing decisions top-down.',
        who: 'Frontline Supervisor / People Manager (primary subject); Change Manager (coaches); affected team (participants)',
        when: 'Signed before Training & Change Readiness phase begins; practiced continuously through hypercare',
        where: 'Team huddles, floor-level 1:1s, shift-change briefings',
        why: "Resistance rooted in a 'done-to-me' perception of change is materially higher than resistance to a change the team helped shape, even in small ways.",
        how: "Structured participation moments (input sessions, pilot feedback loops, visible 'you said / we did' tracking) built into the Communication and Resistance Management macro processes.",
        description:
          'Extends Kotter Step 5 (Enable Action by Removing Barriers) to the supervisor layer; reduces role/will-based resistance surfaced in Module 16.',
      },
    ],
  },
  {
    id: 'CHTR-03',
    name: 'Communication Charter',
    pdcaCycle: 'Full Cycle (Plan-Do-Check-Act)',
    racsi: { R: 'CM', A: 'CM', C: 'ES, FPO', S: 'PM', I: 'SUP, EU' },
    primaryLinkedMacroId: 'MP-03',
    governsObsLevel: 'Project',
    status: 'Active',
    version: 'v1.0',
    effectiveDate: '2026-06-09',
    reviewFrequency: 'Per communication wave',
    entries: [
      {
        id: 'CHTR-03-E1',
        category: 'Communication & Awareness',
        owner: 'Change Manager',
        what: 'Defines the message-audience-channel-timing discipline and the FAQ/reply-protocol standard every communication wave must follow.',
        who: 'Change Manager / Communications Practitioner (primary subject); Executive Sponsor (co-signs key messages)',
        when: 'Signed at communication-plan approval; enforced on every wave thereafter',
        where: 'Module 14 Communication Planning & Execution',
        why: "Ad hoc, inconsistent communication is a leading cause of the Awareness/Desire gap the Interaction Map's Exception E1 describes.",
        how: 'A standing communication matrix (persona x channel x cadence), a mandatory FAQ reply-protocol SLA, and saturation checks (RULE-015) before any wave is scheduled.',
        description:
          'Operationalizes Kotter Step 4 (Communicate the Vision) as an enforceable standard rather than a plan document read once and shelved.',
      },
    ],
  },
  {
    id: 'CHTR-04',
    name: 'Organizational Impact Charter',
    pdcaCycle: 'Full Cycle (Plan-Do-Check-Act)',
    racsi: { R: 'CM', A: 'CM', C: 'FPO, SUP', S: 'PM', I: 'ES, EU' },
    primaryLinkedMacroId: 'MP-01',
    governsObsLevel: 'Project',
    status: 'Active',
    version: 'v1.0',
    effectiveDate: '2026-06-09',
    reviewFrequency: 'On scope change',
    entries: [
      {
        id: 'CHTR-04-E1',
        category: 'Impact & Structure',
        owner: 'Change Manager',
        what: 'Defines the methodology and sign-off standard for assessing how the change affects process, technology, role, location and professional identity.',
        who: 'Change Manager (facilitates); Functional Process Owners (validate); Frontline Supervisors (confirm)',
        when: 'Signed at Discovery & Design phase entry; re-validated at every major scope change',
        where: 'Module 9 Stakeholder & Impact Mapping',
        why: 'An impact assessment done once, informally, and never revisited misses scope creep — the single most common cause of a stale stakeholder map.',
        how: 'A required 5-dimension scoring rubric (RULE-005 human-confirmation gate), mandatory FPO/Supervisor validation sign-off, and a re-validation trigger on scope change.',
        description: 'Formalizes Prosci Impact & Stakeholder Analysis as a governed, re-triggerable process rather than a one-time exercise.',
      },
    ],
  },
  {
    id: 'CHTR-05',
    name: 'Team Coaching Charter',
    pdcaCycle: 'Full Cycle (Plan-Do-Check-Act)',
    racsi: { R: 'SUP', A: 'CM', C: 'ITL', S: 'PM', I: 'ES, FPO, EU' },
    primaryLinkedMacroId: 'MP-09',
    governsObsLevel: 'Project',
    status: 'Active',
    version: 'v1.0',
    effectiveDate: '2026-06-09',
    reviewFrequency: 'Per hypercare phase',
    entries: [
      {
        id: 'CHTR-05-E1',
        category: 'Coaching & Enablement',
        owner: 'People Manager',
        what: 'Defines the standard for group/team-level floor coaching delivered by People Managers during hypercare, distinct from individual 1:1 coaching.',
        who: 'People Manager / Frontline Supervisor (primary subject); Change Manager (equips and audits)',
        when: 'Signed before go-live; active throughout the hypercare window, tapering per MP-09 Task 4',
        where: 'The production floor / work area, not a classroom',
        why: 'Team-level regression is often visible on the floor days before it surfaces in individual metrics; a coaching standard catches it early.',
        how: 'A defined cadence (e.g., daily floor walk during Week 1 of hypercare), a coaching-script standard (AIUC-11-assisted), and an escalation trigger to Change Manager if team-level metrics stall.',
        description:
          'Distinguishes team-level coaching (this charter) from CHTR-06 One-to-One Coaching, which handles individual identity-level concerns.',
      },
    ],
  },
  {
    id: 'CHTR-06',
    name: 'One-to-One Coaching Charter',
    pdcaCycle: 'Full Cycle (Plan-Do-Check-Act)',
    racsi: { R: 'CM', A: 'CM', C: 'FPO', S: 'SUP', I: 'ES, PM, EU' },
    primaryLinkedMacroId: 'MP-08',
    governsObsLevel: 'Project',
    status: 'Active',
    version: 'v1.0',
    effectiveDate: '2026-06-09',
    reviewFrequency: 'Per triggered case',
    entries: [
      {
        id: 'CHTR-06-E1',
        category: 'Coaching & Enablement',
        owner: 'Change Manager',
        what: 'Defines the standard for individual, identity-focused coaching conversations — most notably the divergence-case 1:1s described in Exception E2.',
        who: 'Change Manager or trained People Manager (delivers); the individual employee (subject)',
        when: 'Triggered on a confirmed Divergence Pattern case, a Desire score <= 2 with an unresolved barrier, or an employee self-request',
        where: 'A private, confidential setting — never the open floor',
        why: 'Group coaching cannot address a genuine identity/loss concern; conflating the two risks minimizing what an individual is actually experiencing.',
        how: 'A structured 1:1 protocol (confirm the concern -> distinguish loss from reluctance -> provide closure if a genuine loss is identified -> re-check Bridges only, not Knowledge/Ability) with mandatory Qualitative Coding Workbench logging.',
        description:
          "Directly operationalizes the Framework Interaction Map's Exception E2 recovery workflow as a formal, signed coaching standard rather than ad hoc practice.",
      },
    ],
  },
  {
    id: 'CHTR-07',
    name: 'Mentoring Charter (Trainee -> Observer -> Autonomous)',
    pdcaCycle: 'Full Cycle (Plan-Do-Check-Act)',
    racsi: { R: 'CM', A: 'CM', C: 'FPO, ITL', S: 'PM, SUP', I: 'ES, EU' },
    primaryLinkedMacroId: 'MP-05',
    governsObsLevel: 'Project',
    status: 'Active',
    version: 'v1.0',
    effectiveDate: '2026-06-09',
    reviewFrequency: 'Per mentee cohort',
    entries: [
      {
        id: 'CHTR-07-E1',
        category: 'Coaching & Enablement',
        owner: 'Training Lead',
        what: 'Defines the three-stage progressive mentoring model (Trainee, Observer, Autonomous) that carries an individual from initial training through to independent, unsupervised competence.',
        who: 'Trainer / designated Mentor (delivers); the mentee (subject); Functional Process Owner (validates competency gates)',
        when: 'Begins at Training & Change Readiness phase; each stage transition is a gated event, not a calendar milestone',
        where: 'Sandbox environment (Trainee), live environment under observation (Observer), live environment unsupervised (Autonomous)',
        why: "'Trained' and 'capable' are not the same thing — Module 15 explicitly separates attendance from demonstrated competency; a single training event rarely produces autonomous performance.",
        how: 'A four-part sub-process — Diagnosis (assess starting Knowledge/Ability) -> Training Plan Elaboration (design the stage-gated path) -> Execution (deliver each stage with explicit entry/exit criteria) -> Closure (formal Autonomous sign-off) — see charterActions.js for the full task/step mapping and mentoringStages.js for the three-stage model itself.',
        description:
          "The one charter whose actions span the widest range of tasks/steps — from MP-05 Task 1 (curriculum design) through Task 5 (remediation) — because mentoring is a full-lifecycle discipline, not a single event.",
      },
    ],
  },
  {
    id: 'CHTR-08',
    name: 'Pulse / Interview Charter',
    pdcaCycle: 'Full Cycle (Plan-Do-Check-Act)',
    racsi: { R: 'CM', A: 'CM', C: '-', S: 'PM, SUP', I: 'ES, FPO, EU' },
    primaryLinkedMacroId: 'MP-07',
    governsObsLevel: 'Project',
    status: 'Active',
    version: 'v1.0',
    effectiveDate: '2026-06-09',
    reviewFrequency: 'Per phase gate + ad hoc',
    entries: [
      {
        id: 'CHTR-08-E1',
        category: 'Readiness Diagnostics',
        owner: 'Change Manager',
        what: 'Defines the cadence, instrument standard and consent protocol for every structured pulse survey, rapid pulse, and 1:1 interview used to capture readiness signals.',
        who: 'Change Manager (administers); all impacted cohorts (respondents)',
        when: 'Baseline at project start; recurring at every Phase Gate; rapid pulses around high-anxiety moments (go-live)',
        where: 'Survey platform (structured pulses), floor/desk (rapid pulses), private setting (interviews)',
        why: 'An inconsistent or overly frequent pulse cadence produces survey fatigue and degrades response quality exactly when the signal matters most (around go-live).',
        how: 'A fixed instrument library (baseline, phase-gate, rapid, interview guide), a maximum-frequency rule per population (ties to RULE-015 saturation logic), and mandatory consolidation into the Composite Readiness Index within a defined SLA.',
        description:
          'Standardizes the instruments referenced throughout Module 10/7 and the worked Survey Form exception-handling example under one governing charter.',
      },
    ],
  },
]

export default charters
